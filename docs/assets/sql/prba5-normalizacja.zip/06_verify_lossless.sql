-- Run separately before steps 07-09. Every result must be empty.
SELECT * FROM flat_enrollments EXCEPT SELECT * FROM enrollment_report;
SELECT * FROM enrollment_report EXCEPT SELECT * FROM flat_enrollments;
PRAGMA foreign_key_check;
